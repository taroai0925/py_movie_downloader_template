import z01_template
import z02_template

z01_template.main()
z02_template.make_env_template()
z02_template.main()